import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Vendor extends Connect {

	/* Add Vendor */
	public static void addVendor() throws SQLException{

		System.out.println("Adding Vendor");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Vendor ID : ");
		int vID = scanner.nextInt();

		System.out.print("Enter Vendor Name : ");
		String vName = scanner.nextLine();

		System.out.print("Enter Street Address : ");
		String sAddress = scanner.nextLine();

		System.out.print("Enter City: ");
		String c = scanner.nextLine();

		System.out.print("Enter State : ");
		String s = scanner.nextLine();

		System.out.print("Enter Zipcode : ");
		int zipC = scanner.nextInt();

		System.out.print("Enter Phone No : ");
		String tNo  = scanner.nextLine();
      System.out.println();

		System.out.print("Enter Remittance Information: ");
		String rInfo  = scanner.nextLine();

		System.out.print("Enter Email: ");
		String em  = scanner.nextLine();

		String sql = "insert into Vendor "
				+ " (vendorID, vendorName, streetAddress , city, state, zipcode, telephoneNo, remittanceInfo, email)"
				+ " values (?, ?, ?, ?, ?, ?, ?, ?, ?)";

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt =conn.prepareStatement(sql);
		try {			
			myStmt.setInt(1, vID);
			myStmt.setString(2, vName);
			myStmt.setString(3, sAddress);
			myStmt.setString(4, c);
			myStmt.setString(5, s);
			myStmt.setInt(6, zipC);
			myStmt.setString(7, tNo);
			myStmt.setString(8, rInfo);
			myStmt.setString(9, em);

			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();
			System.out.println("Successfully Inserted Vendor");
		}       
      catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	/* Delete Vendor */
	public static void deleteVendor() throws SQLException {

		System.out.println("Deleting Vendor");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Vendor ID: ");
		int pId = scanner.nextInt();

		String sql = "DELETE FROM Vendor WHERE vendorID = ? ";

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setInt(1, pId);

			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (!sql.isEmpty())

			System.out.println("Vendor not found! Please try again. Thank you!");

		else

			System.out.println("Successfully deleted vendor record");
		

	}

	/* Search Vendor */
	public static void searchVendor() throws SQLException {
      System.out.println("Searching Vendor Record\n");
		ArrayList<String> rowArray = new ArrayList<String>();

		Scanner scanner = new Scanner(System.in);
     /* String password ="";*/int pId; //String verify = "1234";
		//do{
		System.out.print("Enter Vendor ID: ");
		pId = scanner.nextInt();
		
	//	System.out.print("Enter Password: ");
	//	password = scanner.nextLine();

		//}while(!password.matches(verify));
      int count=0;
		
		Connection conn = Connect.getConnection();
      String sql = "select*from vendor where vendorID=?";
      
		// PreparedStatement myStmt;
      
         try {

			PreparedStatement myStmt = conn.prepareStatement(sql);
         
			myStmt.setInt(1, pId);
			ResultSet rs = myStmt.executeQuery();
         System.out.println();
			while (rs.next()) {
				rowArray.add(rs.getString(1));
				rowArray.add(rs.getString(2));
				rowArray.add(rs.getString(3));
				rowArray.add(rs.getString(4));
				rowArray.add(rs.getString(5));
				rowArray.add(rs.getString(6));
				rowArray.add(rs.getString(7));
				rowArray.add(rs.getString(8));
				rowArray.add(rs.getString(9));
				System.out.println(rowArray);
		      count++;
			}
			// myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (count==0)

			System.out.println("Vendor not found! Please try again. Thank you!");

		else

			System.out.println("Successfully found vendor record");
		
	}


public static void updateVendor() throws SQLException{

		System.out.println("Updating Vendor");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Vendor ID: ");
		int vID = scanner.nextInt();

		System.out.print("Enter Updated Vendor Name : ");
		String vName = scanner.nextLine();

		System.out.print("Enter Updated Street Address : ");
		String sAddress = scanner.nextLine();

		System.out.print("Enter Updated City: ");
		String c = scanner.nextLine();

		System.out.print("Enter Updated State : ");
		String s = scanner.nextLine();

		System.out.print("Enter Updated State : ");
		int zipC = scanner.nextInt();

		System.out.print("Enter Updated Phone Number : ");
		String tNo  = scanner.nextLine();

		System.out.print("Enter Updated Remittance Information : ");
		String rInfo  = scanner.nextLine();

		System.out.print("Enter Updated email: ");
		String em  = scanner.nextLine();

		String sql = "UPDATE vendor SET vendorName, streetAddress , city, state, zipcode, telephoneNo, remittanceInfo, email)WHERE vendorID=?";

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt =conn.prepareStatement(sql);
		try {			
   
			
			myStmt.setString(1, vName);
			myStmt.setString(2, sAddress);
			myStmt.setString(3, c);
			myStmt.setString(4, s);
			myStmt.setInt(5, zipC);
			myStmt.setString(6, tNo);
			myStmt.setString(7, rInfo);
			myStmt.setString(8, em);
         myStmt.setInt(1, vID);
			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();
			System.out.println("Successfully Updated Vendor");
		}       
       catch (Exception e) {
			System.err.println(e.getMessage());
			System.err.println("Got an exception! Please try again. Thank you!");
		}	
	}



}
