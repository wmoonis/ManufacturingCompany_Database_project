/*import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import com.mysql.jdbc.Statement;*/
import java.util.Scanner;
import java.sql.SQLException;

public class SwitchOperatedTextMenu{

	public static void showMainMenu()throws SQLException{
		System.out.println("\nWelcome to W Cosmetic Manufacturing Company\n");
		Scanner in = new Scanner(System.in);

		// print menu
		System.out.println("#1:Customer Account");
		System.out.println("#2:Vendor Account ");
		System.out.println("#3:Sales Department Account");
		//System.out.println("#4:Inventory");
		System.out.println("#0:Quit");

		// handle user commands
		boolean quit = false;
		int menuItem;
		do {
			System.out.print("\nChoose Your Account : ");
			menuItem = in.nextInt();
			switch (menuItem) {
			case 1:
				// System.out.println("#1:Customer");
				showCustomerMenu();
				break;
			case 2:
				// System.out.println("#2:Vendor");
				showVendorMenu();
				break;
			case 3:
				// System.out.println("#3:Sales");
				showSalesMenu();
				break;
			// case 4:
			// 	// System.out.println("#4:Inventory");
			// 	showInventoryMenu();
			// 	break;

			case 0:
				quit = true;
				break;
			default:
				System.out.println("Invalid choice.");
			}
		} while (!quit);
		System.out.println("Thank You!");
		in.close();
	}

	/* Customer Menu Details */
	public static void showCustomerMenu()throws SQLException{
		Scanner in = new Scanner(System.in);
		Customer s = new Customer();
		
      System.out.println();
       String password=""; String userName=""; String verify = "1234"; String verify2 = "vendor";
      do{
		System.out.print("Enter Username: ");
		userName = in.nextLine();
		
		System.out.print("Enter the Password: ");
		password = in.nextLine();

		}while(!password.matches(verify)&&!userName.matches(verify2));
      System.out.println();
      s.searchCustomer();

		System.out.println("0. Return to Main Menu");

		//handle user commands
		boolean quit = false;
		int menuItem;
		do {
			//System.out.print("\nChoose Menu Item: ");
			menuItem = in.nextInt();
			switch (menuItem) {
			case 0:
				quit = true;
				break;
			default:
				System.out.println("Invalid choice.");
			}
		} while (!quit);
		System.out.println("\nReturning to main menu\n");
		System.out.println("#1:Customer Account");
		System.out.println("#2:Vendor Account");
		System.out.println("#3:Sales Department Account");
		//System.out.println("#4:Inventory");
		System.out.println("#0:Quit");
		
	}


	/* Vendor Menu Details */
	public static void showVendorMenu()throws SQLException{
		Scanner in = new Scanner(System.in);
		Vendor f = new Vendor();
		System.out.println();
       String password=""; String userName=""; String verify = "1234"; String verify2 = "vendor";
      do{
		System.out.print("Enter Username: ");
		userName = in.nextLine();
		
		System.out.print("Enter the Password: ");
		password = in.nextLine();

		}while((!password.matches(verify))&&!(userName.matches(verify2)));
		System.out.println();
      f.searchVendor();
      
      System.out.println("0. Return to Main menu\n");
		// handle user commands
		boolean quit = false;
		int menuItem;
		do {
			System.out.print("Choose menu item: ");
			menuItem = in.nextInt();
			switch (menuItem) {
			case 0:
				quit = true;
				break;
			default:
				System.out.println("Invalid choice.");
			}
		} while (!quit);
		System.out.println("\nReturning to main menu\n");
		System.out.println("#1:Customer Account");
		System.out.println("#2:Vendor Account");
		System.out.println("#3:Sales Department Account");
		//System.out.println("#4:Inventory");
		System.out.println("#0:Quit");
	
	}


	/* Sales Menu Details */
	public static void showSalesMenu() throws SQLException{
		Scanner in = new Scanner(System.in);
		Sales c = new Sales();
      String password=""; String userName=""; String verify1 = "1234"; String verify2 = "sales";
		do{
		System.out.print("Enter Username: ");
		userName = in.nextLine();
		
		System.out.print("Enter the Password: ");
		password = in.nextLine();

		}while(!(password.matches(verify1)) && !(userName.matches(verify2)));
		// print menu
      System.out.println("Tables: \n");
		System.out.println(1 + ". Vendor");
		System.out.println(2 + ". Customer");
		System.out.println(3 + ". Inventory");
		System.out.println(4 + ". Sales");
		System.out.println(0 + ". Exit");

		System.out.println("0. Return to Main menu\n");
		// handle user commands
		boolean quit = false;
		int menuItem;
		do {
			System.out.print("Choose Table: ");
			menuItem = in.nextInt();
			switch (menuItem) {
			case 1:
				// System.out.println("Vendor");
				vendorTable();

				break;
			case 2:
				// System.out.println("Customer");
				customerTable();
				break;
			case 3:
				// System.out.println("Inventory");
				showInventoryMenu();
				break;
			case 4:
				// System.out.println("Sales");
				salesTable();
				break;
			case 0:
				quit = true;
				break;
			default:
				System.out.println("Invalid choice.");
			}
		} while(!quit);}



	/* Inventory Menu Details */
	 public static void showInventoryMenu()throws SQLException{
		Scanner in = new Scanner(System.in);
		Inventory d = new Inventory();
		// print menu
		System.out.println(1 + ". Add Inventory");
		System.out.println(2 + ". Delete Inventory");
		System.out.println(3 + ". Update Inventory");
		System.out.println(4 + ". Search Inventory");

		System.out.println("0. Return to Main menu\n");
		// handle user commands
		boolean quit = false;
		int menuItem;
		do {
			System.out.print("Choose menu item: ");
			menuItem = in.nextInt();
			switch (menuItem) {
			case 1:
				// System.out.println("Selected add Inventory");
				d.addInventory();

				break;
			case 2:
				// System.out.println("selected delete Inventory");
				d.deleteInventory();
				break;
			case 3:
				// System.out.println("selected update Inventory");
				d.updateInventory();
				break;
			case 4:
				// System.out.println("selected search Inventory");
				d.searchInventory();
				break;
			case 0:
				quit = true;
				break;
			default:
				System.out.println("Invalid choice.");
			}
		} while (!quit);
		System.out.println("\nReturning to main menu\n");
		System.out.println("#1:Customer Account");
		System.out.println("#2:Vendor Account");
		System.out.println("#3:Sales Department Account");
		//System.out.println("#4:Inventory");
		System.out.println("#0:Quit");
		
	}

	/* Customer Table Details */
	public static void customerTable() throws SQLException{
		Scanner in = new Scanner(System.in);
		Customer s = new Customer();
		// print menu
		System.out.println(1 + ". Add Customer");
		System.out.println(2 + ". Delete Customer");
		System.out.println(3 + ". Update Customer");
		System.out.println(4 + ". Search Customer");
		//System.out.println("Enter User Name : ");

		System.out.println("0. Return to Main Menu");

		//handle user commands
		boolean quit = false;
		int menuItem;
		do {
			//System.out.print("\nChoose Menu Item: ");
			menuItem = in.nextInt();
			switch (menuItem) {
			case 1:
				// System.out.println("Add Customer");
				s.addCustomer();
				break;
			case 2:
				// System.out.println("Delete Customer");
				s.deleteCustomer();
				break;
			case 3:
				// System.out.println("Update Customer");
				s.updateCustomer();
				break;
			case 4:
				// System.out.println("Search Customer");
				s.searchCustomer();
				break;
			case 0:
				quit = true;
				break;
			default:
				System.out.println("Invalid choice.");
			}
		} while (!quit);
		System.out.println("\nReturning to main menu\n");
		System.out.println(1 + ". Vendor");
		System.out.println(2 + ". Customer");
		System.out.println(3 + ". Inventory");
		System.out.println(4 + ". Sales");
		System.out.println(0 + ". Exit");
	}

	public static void vendorTable() throws SQLException{
		Scanner in = new Scanner(System.in);
		Vendor f = new Vendor();
		// print menu
		System.out.println(1 + ". Add Vendor");
		System.out.println(2 + ". Delete Vendor");
		System.out.println(3 + ". Update Vendor");
		System.out.println(4 + ". Search Vendor");

		System.out.println("0. Return to Main menu\n");
		// handle user commands
		boolean quit = false;
		int menuItem;
		do {
			System.out.print("Choose menu item: ");
			menuItem = in.nextInt();
			switch (menuItem) {
			case 1:
				// System.out.println("Selected add Vendor");
				f.addVendor();

				break;
			case 2:
				// System.out.println("selected delete Vendor");
				f.deleteVendor();
				break;
			case 3:
				// System.out.println("selected update Vendor");
				f.updateVendor();
				break;
			case 4:
				// System.out.println("selected search Vendor");
				f.searchVendor();
				break;
			case 0:
				quit = true;
				break;
			default:
				System.out.println("Invalid choice.");
			}
		} while (!quit);
		System.out.println("\nReturning to main menu\n");
		System.out.println(1 + ". Vendor");
		System.out.println(2 + ". Customer");
		System.out.println(3 + ". Inventory");
		System.out.println(4 + ". Sales");
		System.out.println(0 + ". Exit");
	}

	/* Sales Table Details */
	public static void salesTable() throws SQLException{
		Scanner in = new Scanner(System.in);
		Sales c = new Sales();
		//Print Menu
		System.out.println(1 + ". Add Sales");
		System.out.println(2 + ". Delete Sales");
		System.out.println(3 + ". Update Sales");
		System.out.println(4 + ". Search Sales");
		boolean quit = false;
		int menuItem;
			do{System.out.print("Choose menu Item: ");
			menuItem = in.nextInt();
			switch (menuItem) {
			case 1:
				// System.out.println("Selected add Sales");
				c.addSales();

				break;
			case 2:
				// System.out.println("selected delete Sales");
				c.deleteSales();
				break;
			case 3:
				// System.out.println("selected update Sales");
				c.updateSales();
				break;
			case 4:
				// System.out.println("selected search Sales");
				c.searchSales();
				break;
			case 0:
				quit = true;
				break;
			default:
				System.out.println("Invalid choice.");
			}
		} while (!quit);
		System.out.println("\nReturning to main menu\n");
		System.out.println(1 + ". Vendor");
		System.out.println(2 + ". Customer");
		System.out.println(3 + ". Inventory");
		System.out.println(4 + ". Sales");
		System.out.println(0 + ". Exit");
		
	}

}


