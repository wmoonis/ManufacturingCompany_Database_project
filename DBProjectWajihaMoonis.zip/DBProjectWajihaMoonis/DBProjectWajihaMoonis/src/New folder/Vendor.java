import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Vendor extends SqlConnection {

	/* Add Vendor */
	public void addVendor() {

		// System.out.println("Add Vendor");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter vendor ID : ");
		Int vendorID = scanner.nextInt();

		System.out.print("Enter Vendor Name : ");
		String vendorName = scanner.nextLine();

		System.out.print("Enter Street Address : ");
		String streetAddress = scanner.nextLine();

		System.out.print("Enter City: ");
		String city = scanner.nextLine();

		System.out.print("Enter state : ");
		String state = scanner.nextLine();

		System.out.print("Enter state : ");
		int zipcode = scanner.nextInt();

		System.out.print("Enter telephoneNo : ");
		String telephoneNo  = scanner.nextLine();

		System.out.print("Enter telephoneNo : ");
		String remittanceInfo  = scanner.nextLine();

		System.out.print("Enter telephoneNo : ");
		String email  = scanner.nextLine();

		String sql = "insert into Vendor "
				+ " (vendorID, vendorName, streetAddress , city, state, zipcode, telephoneNo, remittanceInfo, email)"
				+ " values (?, ?, ?, ?, ?, ?, ?, ?, ?)";

		Connection conn = SqlConnection.dbConnector();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, vendorID);
			myStmt.setString(2, vendorName);
			myStmt.setString(3, streetAddress);
			myStmt.setString(4, city);
			myStmt.setString(5, state);
			myStmt.setString(6, zipcode);
			myStmt.setString(7, telephoneNo);
			myStmt.setString(8, remittanceInfo);
			myStmt.setString(9, email);

			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();
			System.out.println("Successfully Inserted Vendor");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	/* Delete Vendor */
	public void deleteVendor() {

		// System.out.println("Delete a Vendor");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the Vendor Id: ");
		int pId = scanner.nextInt();

		String sql = "DELETE FROM Vendor WHERE vendorID = ? ";

		Connection conn = SqlConnection.dbConnector();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setInt(1, pId);

			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (!sql.isEmpty())

			System.out.println("Vendor Not found");

		else

			System.out.println("Successfully deleted Vendor record");
		

	}

	/* Search Vendor */
	public void searchVendor() {

		ArrayList<String> rowArray = new ArrayList<String>();

		Scanner scanner = new Scanner(System.in);

		do{
		System.out.print("Enter the Vendor Id: ");
		int pId = scanner.nextInt();
		
		System.out.print("Enter the Password: ");
		String password = scanner.nextLine();

		}while(password!='1234');

		String sql = "SELECT * FROM Vendor WHERE vendorID = "+pId;
		Connection conn = SqlConnection.dbConnector();
		// PreparedStatement myStmt;
		try {

			PreparedStatement myStmt = conn.prepareStatement(sql);
			myStmt.setInt(1, pId);
			ResultSet rs = myStmt.executeQuery();

			while (rs.next()) {
				rowArray.add(rs.getString(1));
				rowArray.add(rs.getString(2));
				rowArray.add(rs.getString(3));
				rowArray.add(rs.getString(4));
				rowArray.add(rs.getString(5));
				rowArray.add(rs.getString(6));
				rowArray.add(rs.getString(7));
				rowArray.add(rs.getString(8));
				rowArray.add(rs.getString(9));
				System.out.println(rowArray);
		
			}
			// myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (!sql.isEmpty())

			System.out.println("Vendor Account Not found");

		else

			System.out.println("Successfully found Vendor record");
		
	}

}
