import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Customer extends Connect{

	public void addCustomer() {
		// System.out.println("Add Customer");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Customer ID: ");
		String customerID = scanner.nextLine();

		System.out.print("Enter Customer Name: ");
		String customerName = scanner.nextLine();

		System.out.print("Enter Customer Billing Address : ");
		String billingAddress  = scanner.nextLine();

		System.out.print("Enter Customer Shipping Address: ");
		String shippingAddress  = scanner.nextLine();

		System.out.print("Enter Customer City: ");
		String city  = scanner.nextLine();

		System.out.print("Enter Customer State: ");
		String state  = scanner.nextLine();

		System.out.print("Enter Customer zipCode: ");
		String zipcode  = scanner.nextLine();

		System.out.print("Enter Customer Phone No: ");
		String telephoneNo  = scanner.nextLine();

		System.out.print("Enter Customer Email: ");
		String email = scanner.nextLine();

		String sql = "insert into customer"
				+ " (customerID, customerName, billingAddress, shippingAddress, city,state,zipcode, telephoneNo, email)"
				+ " values (?, ?, ?,?,?,?,?,?,?)";

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, customerID);
			myStmt.setString(2, customerName);
			myStmt.setString(3, billingAddress);
			myStmt.setString(4, shippingAddress);
			myStmt.setString(5, city);
			myStmt.setString(6, state);
			myStmt.setString(7, zipcode);
			myStmt.setString(8, telephoneNo);
			myStmt.setString(9, email);
			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();
			System.out.println("Successfully inserted Customer record");
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");

		}


	}

	public void deleteCustomer() {

		// System.out.println("Delete a cId");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the Customer Id to delete: ");
		int cId = scanner.nextInt();

		String sql = "DELETE FROM Customer WHERE customerID = ? ";

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setInt(1, cId);

			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();

			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");
		}

		if (sql.isEmpty())

			System.out.println("Customer Not found");

		else

			System.out.println("Successfully deleted Customer record");
		

	}

	/* Update Customer */
	public void updateCustomer() {
		System.out.println("Customer update");

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Customer ID: ");
		String customerID = scanner.nextLine();

		System.out.print("Enter Customer Name: ");
		String customerName = scanner.nextLine();

		System.out.print("Enter Customer Billing Address : ");
		String billingAddress  = scanner.nextLine();

		System.out.print("Enter Customer Shipping Address: ");
		String shippingAddress  = scanner.nextLine();

		System.out.print("Enter Customer City: ");
		String city  = scanner.nextLine();

		System.out.print("Enter Customer State: ");
		String state  = scanner.nextLine();

		System.out.print("Enter Customer zipCode: ");
		String zipcode  = scanner.nextLine();

		System.out.print("Enter Customer Phone No: ");
		String telephoneNo  = scanner.nextLine();

		System.out.print("Enter Customer Phone No: ");
		String email = scanner.nextLine();

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;

		try {

			// create the java mysql update preparedstatement

			String sql = "Update Customer set customerName = ?,billingAddress=?, shippingAddress=?,city =?,state =?,zipcode =?,telephoneNo =?,email =?  where customerID = ?";
			// PreparedStatement preparedStmt = conn.prepareStatement(query);
			myStmt = conn.prepareStatement(sql);

			myStmt.setString(1, customerName);
			myStmt.setString(2, billingAddress);
			myStmt.setString(3, shippingAddress);
			myStmt.setString(4, city);
			myStmt.setString(5, state);
			myStmt.setString(6, zipcode);
			myStmt.setString(7, telephoneNo);
			myStmt.setString(8, email);

			// execute the java preparedstatement

			myStmt.executeUpdate();

			conn.close();
		} catch (Exception e) {
			// System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");
		}
		System.out.println("Successfully Updated Customer details");

	}

	/* Search Customer */
	public void searchCustomer() {

		ArrayList<String> rowArray = new ArrayList<String>();
		// System.out.println("Enter Customer name:");
		// System.out.println("Search a Customer");
		Scanner scanner = new Scanner(System.in);
      String password="";
      String cId;
     
		do{
		System.out.print("Enter Customer ID: ");
		cId = scanner.nextLine();
		
		System.out.print("Enter the Password: ");
		 password = scanner.nextLine();

		}while(password!="1234");

		String sql = "SELECT * FROM Customer WHERE customerID = ?";
		Connection conn = Connect.getConnection();
		// PreparedStatement myStmt;
		try {

			PreparedStatement myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, cId);
			ResultSet rs = myStmt.executeQuery();

			while (rs.next()) {
				rowArray.add(rs.getString(1));
				rowArray.add(rs.getString(2));
				rowArray.add(rs.getString(3));
				rowArray.add(rs.getString(4));
				rowArray.add(rs.getString(5));
				rowArray.add(rs.getString(6));
				rowArray.add(rs.getString(7));
				rowArray.add(rs.getString(8));
				rowArray.add(rs.getString(9));
				System.out.println(rowArray);
			}

			// myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();

			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");
		}
		if (sql.isEmpty()) {
			System.out.println("Customer Not found");
		} else {
			System.out.println("Successfully found Customer record");
		}		
	}

}
