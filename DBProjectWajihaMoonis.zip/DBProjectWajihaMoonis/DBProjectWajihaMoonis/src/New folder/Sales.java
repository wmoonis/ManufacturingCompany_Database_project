import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Sales extends SqlConnection {

	public void addSales() {
		// System.out.println("Add Course");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter sales Transaction No: ");
		String salesTransactionNo  = scanner.nextLine();

		System.out.print("Enter Item Code : ");
		String itemCode = scanner.nextLine();

		System.out.print("Enter Customer ID : ");
		String customerID = scanner.nextLine();

		System.out.print("Enter vendor ID: ");
		int vendorID = scanner.nextInt();

		System.out.print("Enter Unit Price_USD: ");
		Double unitPrice_USD = scanner.nextDouble();

		System.out.print("Enter Quantiity : ");
		int quantiity = scanner.nextInt();

		System.out.print("Enter Customer ID : ");
		String salesDate = scanner.nextLine();

		String sql = "insert into Sales "
				+ " (salesTransactionNo, itemCode, customerID, vendorID, unitPrice_USD, quantiity, salesDate)"
				+ " values (?, ?, ?, ?, ?, ?, ?)";

		Connection conn = SqlConnection.dbConnector();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, salesTransactionNo);
			myStmt.setString(2, itemCode);
			myStmt.setString(3, customerID);
			myStmt.setString(4, vendorID);
			myStmt.setString(5, unitPrice_USD);
			myStmt.setString(6, quantiity);
			myStmt.setString(7, salesDate);

			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();
			System.out.println("Successfully Inserted New Sales");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");
		}
	

	}

	/* Delete Sales */

	public void deleteSales() {

		System.out.println("Delete a Faculty");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the Sales Transaction No : ");
		int dNumber = scanner.nextInt();

		String sql = "DELETE FROM Sales WHERE salesTransactionNo = ? ";

		Connection conn = SqlConnection.dbConnector();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setInt(1, dNumber);

			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");
		}
		if (!sql.isEmpty())

			System.out.println("Sales Not found");

		else

			System.out.println("Successfully deleted Sales record");
	

	}

	/* Update Sales */
	public void updateSales() {
		System.out.println("Student course");

		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter sales Transaction No: ");
		String salesTransactionNo  = scanner.nextLine();

		System.out.print("Enter Item Code : ");
		String itemCode = scanner.nextLine();

		System.out.print("Enter Customer ID : ");
		String customerID = scanner.nextLine();

		System.out.print("Enter vendor ID: ");
		int vendorID = scanner.nextInt();

		System.out.print("Enter Unit Price_USD: ");
		Double unitPrice_USD = scanner.nextDouble();

		System.out.print("Enter Quantiity : ");
		int quantiity = scanner.nextInt();

		System.out.print("Enter Customer ID : ");
		String salesDate = scanner.nextLine();

		Connection conn = SqlConnection.dbConnector();
		PreparedStatement myStmt;

		try {

			// create the java mysql update preparedstatement

			// String sql =
			// "Update Sales set dChairmanF_Name=? where dNumber = ?";
			// PreparedStatement preparedStmt = conn.prepareStatement(query);
			// String sql = "UPDATE " + dChairmanF_Name +" SET " +
			// dChairmanF_Name + "=IFNULL(? ," + dChairmanF_Name + ")  WHERE " +
			// dNumber + "=?";

			/*
			 * String sql =
			 * "UPDATE  Sales SET  dChairmanF_Name =IFNULL(? ,dChairmanF_Name),"
			 * + "dChairmanL_Name = IFNULL(? ,dChairmanL_Name)" +
			 * "WHERE dNumber =?";
			 */

			String sql = "UPDATE Sales SET ";

			if (null != salesTransactionNo) {
				sql += " salesTransactionNo = ?,";
			}

			if (null != itemCode) {
				sql += " itemCode = ?";
			}

			sql += " WHERE salesTransactionNo =?";

			myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, salesTransactionNo);
			myStmt.setString(2, itemCode);
			myStmt.setString(3, customerID);
			myStmt.setString(4, vendorID);
			myStmt.setString(5, unitPrice_USD);
			myStmt.setString(6, quantiity);
			myStmt.setString(7, salesDate);

			// execute the java preparedstatement

			myStmt.executeUpdate();

			conn.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");
		}
		System.out.println("Successfully Updated Sales details");
	
	}

	/* Search Sales */
	public void searchSales() {

		ArrayList<String> rowArray = new ArrayList<String>();

		Scanner scanner = new Scanner(System.in);
		String sql = "SELECT * FROM Sales WHERE salesTransactionNo = ?";
		System.out.print("Enter the sales Transaction No :  ");
		int dNumber = scanner.nextInt();

		Connection conn = SqlConnection.dbConnector();
		// PreparedStatement myStmt;
		try {

			PreparedStatement myStmt = conn.prepareStatement(sql);
			myStmt.setInt(1, dNumber);
			ResultSet rs = myStmt.executeQuery();

			while (rs.next()) {
				rowArray.add(rs.getString(1));
				rowArray.add(rs.getString(2));
				rowArray.add(rs.getString(3));
				rowArray.add(rs.getString(4));
				rowArray.add(rs.getString(5));
				rowArray.add(rs.getString(6));
				rowArray.add(rs.getString(7));

				System.out.println(rowArray);
			}
			// myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");
		}
		if (!sql.isEmpty())

			System.out.println("Sales Not found");

		else

			System.out.println("Successfully searched Sales record");


	}

}
