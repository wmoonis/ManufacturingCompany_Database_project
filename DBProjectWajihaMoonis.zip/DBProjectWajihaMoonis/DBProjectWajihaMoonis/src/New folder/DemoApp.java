import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DemoApp {

	public static void main(String[] args) {

		Connection conn = connect.dbConnector();
		System.out.println("connection :" + conn);
		try {
			PreparedStatement stmt = conn
					.prepareStatement("Select * from Inventory");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				// System.out.println("_____" + rs.getString("pid"));
			}
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		SwitchOperatedTextMenu.showMainMenu();
		System.exit(0);
	}
}
