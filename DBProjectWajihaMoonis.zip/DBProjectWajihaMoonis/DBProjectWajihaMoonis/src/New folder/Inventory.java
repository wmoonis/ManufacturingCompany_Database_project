import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Inventory extends SqlConnection {

	public void addInventory() {

		// System.out.println("Add Inventory");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Item Code : ");
		String itemCode = scanner.nextLine();

		System.out.print("Enter Inventory Product Name: ");
		String productName = scanner.nextLine();

		System.out.print("Enter Inventory quantity / capacity: ");
		String quantity = scanner.nextLine();

		System.out.print("Enter Manufacturing Date : ");
		String manufacturingDate = scanner.nextLine();

		System.out.print("Enter Expiration Date : ");
		String expirationDate = scanner.nextLine();

		System.out.print("Enter unit Cost in USD : ");
		Double unitCost_USD = scanner.nextDouble();

		System.out.print("Enter Vendor ID ");
		int vendorID = scanner.nextInt();

		String sql = "insert into Inventory "
				+ " (itemCode, productName, quantity,manufacturingDate,expirationDate,unitCost_USD,vendorID)"
				+ " values (?, ?, ?, ?, ?, ?, ?)";

		Connection conn = SqlConnection.dbConnector();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, itemCode);
			myStmt.setString(2, productName);
			myStmt.setString(3, quantity);
			myStmt.setString(4, manufacturingDate);
			myStmt.setString(5, expirationDate);
			myStmt.setString(6, unitCost_USD);
			myStmt.setString(7, vendorID);
			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();
			System.out.println("Successfully Inserted Inventory record");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");
		}


	}

	/* Delete Inventory */
	public void deleteInventory() {

		System.out.println("Delete a Inventory");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the Inventory itemCode: ");
		String InventoryNo = scanner.nextLine();

		String sql = "DELETE FROM Inventory WHERE itemCode = ? ";

		Connection conn = SqlConnection.dbConnector();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setInt(1, inventoryNo);

			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");
		}
		if (!sql.isEmpty())

			System.out.println("Inventory Not found");

		else

			System.out.println("Successfully deleted Inventory record");
	
	}

	/* Update Inventory */
	public void updateInventory() {
		System.out.println("Sales Inventory");

		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Item Code : ");
		String itemCode = scanner.nextLine();

		System.out.print("Enter Inventory Product Name: ");
		String productName = scanner.nextLine();

		System.out.print("Enter Inventory quantity / capacity: ");
		String quantity = scanner.nextLine();

		System.out.print("Enter Manufacturing Date : ");
		String manufacturingDate = scanner.nextLine();

		System.out.print("Enter Expiration Date : ");
		String expirationDate = scanner.nextLine();

		System.out.print("Enter unit Cost in USD : ");
		Double unitCost_USD = scanner.nextDouble();

		System.out.print("Enter Vendor ID ");
		int vendorID = scanner.nextInt();

		Connection conn = SqlConnection.dbConnector();
		PreparedStatement myStmt;

		try {

			// create the java mysql update preparedstatement

			String sql = "Update Inventory set productName =?, quantity =?,manufacturingDate =?,expirationDate =?,unitCost_USD =?,vendorID =? where itemCode = ?";
			// PreparedStatement preparedStmt = conn.prepareStatement(query);
			myStmt = conn.prepareStatement(sql);

			myStmt.setString(1, productName);
			myStmt.setString(2, quantity);
			myStmt.setString(3, manufacturingDate);
			myStmt.setString(4, expirationDate);
			myStmt.setString(5, unitCost_USD);
			myStmt.setString(6, vendorID);

			// execute the java preparedstatement

			myStmt.executeUpdate();

			conn.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");
		}
		System.out.println("Successfully Updated Inventory details");


	}

	/* Search Inventory */
	public void searchInventory() {

		ArrayList<String> rowArray = new ArrayList<String>();

		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the Inventory ItemCode: ");
		String itemCode = scanner.nextLine();
		String sql = "SELECT * FROM Inventory WHERE itemCode = ?";

		Connection conn = SqlConnection.dbConnector();
		// PreparedStatement myStmt;
		try {

			PreparedStatement myStmt = conn.prepareStatement(sql);
			myStmt.setInt(1, itemCode);
			ResultSet rs = myStmt.executeQuery();

			while (rs.next()) {
				rowArray.add(rs.getString(1));
				rowArray.add(rs.getString(2));
				rowArray.add(rs.getString(3));
				rowArray.add(rs.getString(4));
				rowArray.add(rs.getString(5));
				rowArray.add(rs.getString(6));
				System.out.println(rowArray);
			}
			// myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception! ");
		}
		if (!sql.isEmpty())

			System.out.println("Inventory Not found");

		else

			System.out.println("Successfully searched Inventory record");
	

	}

}
