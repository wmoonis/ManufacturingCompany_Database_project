import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DemoApp {

	public static void main(String[] args)throws SQLException {

		Connection conn = Connect.getConnection();
		System.out.println("connection :" + conn);
		try {
			PreparedStatement stmt = conn
					.prepareStatement("Select * from Inventory");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				
			}
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		SwitchOperatedTextMenu.showMainMenu();
		System.exit(0);
	}
}
