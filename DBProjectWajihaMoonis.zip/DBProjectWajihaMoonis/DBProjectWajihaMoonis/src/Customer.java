import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Customer extends Connect{

	public static void addCustomer() throws SQLException{
		System.out.println("Add A New Customer");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Customer ID: ");
		String cID = scanner.nextLine();

	System.out.print("Enter Customer Name: ");
		String cName = scanner.nextLine();

		System.out.print("Enter Customer Billing Address : ");
		String bAddress  = scanner.nextLine();

		System.out.print("Enter Customer Shipping Address: ");
		String sAddress  = scanner.nextLine();

		System.out.print("Enter Customer City: ");
		String c  = scanner.nextLine();

		System.out.print("Enter Customer State: ");
		String s  = scanner.nextLine();

		System.out.print("Enter Customer Zipcode: ");
		String zipC  = scanner.nextLine();

		System.out.print("Enter Customer Phone No: ");
		String tNo  = scanner.nextLine();

		System.out.print("Enter Customer Email: ");
		String em = scanner.nextLine();

		String sql = "insert into customer"
				+ " (customerID, customerName, billingAddress, shippingAddress, city,state,zipcode, telephoneNo, email)"
				+ " values (?, ?, ?,?,?,?,?,?,?)";

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, cID);
			myStmt.setString(2, cName);
			myStmt.setString(3, bAddress);
			myStmt.setString(4, sAddress);
			myStmt.setString(5, c);
			myStmt.setString(6, s);
			myStmt.setString(7, zipC);
			myStmt.setString(8, tNo);
			myStmt.setString(9, em);
			
			myStmt.executeUpdate();
			conn.close();
			System.out.println("Successfully inserted a customer record! ");
		} catch (SQLException e) {
			System.err.println(e.getMessage());
			System.err.println("Got an exception!Please try again. Thank you! ");

		}


	}

	public static void deleteCustomer()throws SQLException {

	
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Customer ID to Delete: ");
		String cId = scanner.nextLine();

		String sql = "DELETE FROM Customer WHERE customerID = ? ";

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, cId);

	
			myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
		

			System.err.println(e.getMessage());
			System.err.println("Got an exception!Please try again. Thank you! ");
		}

		if (sql.isEmpty())

			System.out.println("Customer Not found");

		else

			System.out.println("Successfully deleted a customer record! ");
		

	}

	public static void updateCustomer()throws SQLException {
		System.out.println("Customer Update");

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Customer ID: ");
		String cID = scanner.nextLine();

		System.out.print("Enter Customer Name: ");
		String cName = scanner.nextLine();

		System.out.print("Enter Customer Billing Address : ");
		String bAddress  = scanner.nextLine();

		System.out.print("Enter Customer Shipping Address: ");
		String sAddress  = scanner.nextLine();

		System.out.print("Enter Customer City: ");
		String c  = scanner.nextLine();

		System.out.print("Enter Customer State: ");
		String s  = scanner.nextLine();

		System.out.print("Enter Customer zipCode: ");
		String zipC  = scanner.nextLine();

		System.out.print("Enter Customer Phone No: ");
		String tNo  = scanner.nextLine();

		System.out.print("Enter Customer Phone No: ");
		String em = scanner.nextLine();

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;

		try {

			// create the java mysql update preparedstatement

			String sql = "Update Customer set customerName = ?,billingAddress=?, shippingAddress=?,city =?,state =?,zipcode =?,telephoneNo =?,email =?  where customerID = ?";
			// PreparedStatement preparedStmt = conn.prepareStatement(query);
			myStmt = conn.prepareStatement(sql);

			myStmt.setString(1, cName);
			myStmt.setString(2, bAddress);
			myStmt.setString(3, sAddress);
			myStmt.setString(4, c);
			myStmt.setString(5, s);
			myStmt.setString(6, zipC);
			myStmt.setString(7, tNo);
			myStmt.setString(8, em);

			// execute the java preparedstatement

			myStmt.executeUpdate();

			conn.close();
		} catch (Exception e) {
			// System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
			System.err.println("Got an exception!Please try again. Thank you! ");
		}
		System.out.println("Successfully updated customer details! ");

	}

	/* Search Customer */
	public static void searchCustomer() throws SQLException{

		ArrayList<String> rowArray = new ArrayList<String>();
		// System.out.println("Enter Customer name:");
		System.out.println("Searching Customer Record\n");
		Scanner scanner = new Scanner(System.in);
      //String password="";
      String cId;//String verify = "1234";
     
		//do{
		System.out.print("Enter Customer ID: ");
		cId = scanner.nextLine(); 
		
		//System.out.print("Enter the Password: ");
		 //password = scanner.nextLine();

		//}while(!password.matches(verify));
      //String a="";
      int count=0;
		String sql = "SELECT * FROM Customer WHERE customerID = ?";
		Connection conn = Connect.getConnection();
		// PreparedStatement myStmt;
		try {

			PreparedStatement myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, cId);
			ResultSet rs = myStmt.executeQuery();

			System.out.println();
         
         while (rs.next()) {
				rowArray.add(rs.getString(1));
				rowArray.add(rs.getString(2));
				rowArray.add(rs.getString(3));
				rowArray.add(rs.getString(4));
				rowArray.add(rs.getString(5));
				rowArray.add(rs.getString(6));
				rowArray.add(rs.getString(7));
				rowArray.add(rs.getString(8));
				rowArray.add(rs.getString(9));
           	System.out.println(rowArray);
			   count++;
         }

			// myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();

			System.err.println(e.getMessage());
			System.err.println("Got an exception! Please try again. Thank you!");
		}
		if (count==0) {
			System.out.println("Customer Not Found! Please try again. Thank you!");
		} else {
			System.out.println("Successfully found the customer record");
		}		
	}

}
