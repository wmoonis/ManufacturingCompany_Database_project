import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Inventory extends Connect {
static int count;
	public static void addInventory()throws SQLException{

		// System.out.println("Add Inventory");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Item Code : ");
		String iCode = scanner.nextLine();

		System.out.print("Enter Inventory Product Name: ");
		String pName = scanner.nextLine();

		System.out.print("Enter Inventory quantity: ");
		int qty = scanner.nextInt();

		System.out.print("Enter Manufacturing Date (YYYY-MM-DD) : ");
		String mDate = scanner.nextLine();

		System.out.print("Enter Expiration Date(YYYY-MM-DD) : ");
		String eDate = scanner.nextLine();

		System.out.print("Enter unit Cost in USD (For Example: 10.00): ");
		Double uCost = scanner.nextDouble();

		System.out.print("Enter Vendor ID ");
		int vID = scanner.nextInt();

		String sql = "insert into Inventory "
				+ " (itemCode, productName, quantity,manufacturingDate,expirationDate,unitCost_USD,vendorID)"
				+ " values (?, ?, ?, ?, ?, ?, ?)";

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, iCode);
			myStmt.setString(2, pName);
			myStmt.setInt(3, qty);
			myStmt.setString(4, mDate);
			myStmt.setString(5, eDate);
			myStmt.setDouble(6, uCost);
			myStmt.setInt(7, vID);
			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();
			System.out.println("Successfully inserted inventory record");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception! Please try again. Thank you!");
		}


	}

	/* Delete Inventory */
	public static void deleteInventory() throws SQLException{
      
		System.out.println("Deleting Inventory");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter The Inventory ItemCode: ");
		String InventoryNo = scanner.nextLine();
      
      String sql = "DELETE FROM Inventory WHERE itemCode = ? ";

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;
      		try {
			myStmt = conn.prepareStatement(sql);
         //PreparedStatement myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, InventoryNo);
         

			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception! Please try again. Thank you!");
		}
		if (count==0)

			System.out.println("Inventory Not found");

		else

			System.out.println("Successfully deleted Inventory record");
	
	}

	/* Update Inventory */
	public static void updateInventory() throws SQLException{
		System.out.println("Updating Inventory");

		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Item Code : ");
		String iCode = scanner.nextLine();

		System.out.print("Enter Inventory Product Name: ");
		String pName = scanner.nextLine();

		System.out.print("Enter Inventory quantity ");
		int qty = scanner.nextInt();

		System.out.print("Enter Manufacturing Date : ");
		String mDate = scanner.nextLine();

		System.out.print("Enter Expiration Date : ");
		String eDate = scanner.nextLine();

		System.out.print("Enter unit Cost in USD : ");
		Double uCost = scanner.nextDouble();

		System.out.print("Enter Vendor ID ");
		int vID = scanner.nextInt();

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;

		try {

			// create the java mysql update preparedstatement

			String sql = "Update Inventory set productName =?, quantity =?,manufacturingDate =?,expirationDate =?,unitCost_USD =?,vendorID =? where itemCode = ?";
			// PreparedStatement preparedStmt = conn.prepareStatement(query);
			myStmt = conn.prepareStatement(sql);

			myStmt.setString(1, pName);
			myStmt.setInt(2, qty);
			myStmt.setString(3, mDate);
			myStmt.setString(4, eDate);
			myStmt.setDouble(5, uCost);
			myStmt.setInt(6, vID);

			// execute the java preparedstatement

			myStmt.executeUpdate();

			conn.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.err.println("Got an exception! Please try again. Thank you!");
		}
		System.out.println("Successfully updated inventory details");


	}

	/* Search Inventory */
	public static void searchInventory() throws SQLException {
      System.out.println("Searching Inventory\n");
		ArrayList<String> rowArray = new ArrayList<String>();
      count=0;
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Inventory ItemCode: ");
		String iCode = scanner.nextLine();
		String sql = "SELECT * FROM Inventory WHERE itemCode = ?";
      //ArrayList<String> rowArray = new ArrayList<String>();

		Connection conn = Connect.getConnection();
		// PreparedStatement myStmt;
		try {

			PreparedStatement myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, iCode);
			ResultSet rs = myStmt.executeQuery();
         System.out.println();
			while (rs.next()) {
				rowArray.add(rs.getString(1));
				rowArray.add(rs.getString(2));
				rowArray.add(rs.getString(3));
				rowArray.add(rs.getString(4));
				rowArray.add(rs.getString(5));
				rowArray.add(rs.getString(6));
				System.out.println(rowArray);
            count++;
			}
			// myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception! Please try again. Thank you!");
		}
		if (count==0)

			System.out.println("Inventory Not Found! Please try again. Thank you!");

		else

			System.out.println("Successfully found the inventory record");
	

	}

}
