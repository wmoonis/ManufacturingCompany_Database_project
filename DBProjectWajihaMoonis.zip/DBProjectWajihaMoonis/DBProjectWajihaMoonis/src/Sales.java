import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Sales extends Connect {

	public static void addSales() throws SQLException{
		System.out.println("Adding Sales");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Sales Transaction No: ");
		String sTransactionNo  = scanner.nextLine();

		System.out.print("Enter Item Code : ");
		String iCode = scanner.nextLine();

		System.out.print("Enter Customer ID : ");
		String cID = scanner.nextLine();

		System.out.print("Enter Vendor ID: ");
		int vID = scanner.nextInt();

		System.out.print("Enter Unit Price_USD: ");
		Double uPrice = scanner.nextDouble();

		System.out.print("Enter Quantity : ");
		int qty = scanner.nextInt();

		System.out.print("Enter Customer ID : ");
		String sDate = scanner.nextLine();

		String sql = "insert into Sales "
				+ " (salesTransactionNo, itemCode, customerID, vendorID, unitPrice_USD, quantity, salesDate)"
				+ " values (?, ?, ?, ?, ?, ?, ?)";

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, sTransactionNo);
			myStmt.setString(2, iCode);
			myStmt.setString(3, cID);
			myStmt.setInt(4, vID);
			myStmt.setDouble(5, uPrice);
			myStmt.setInt(6, qty);
			myStmt.setString(7, sDate);

			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();
			System.out.println("Successfully inserted new sales");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception! Please try again. Thank you!");
		}
	

	}

	

	public static void deleteSales() throws SQLException{
   
		System.out.println("Deleting Sales Record");
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Sales Transaction No : ");
		int dNumber = scanner.nextInt();

		String sql = "DELETE FROM Sales WHERE salesTransactionNo = ? ";

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;
		try {
			myStmt = conn.prepareStatement(sql);
			myStmt.setInt(1, dNumber);

			// 3. Execute SQL query
			myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception!Please try again. Thank you! ");
		}
		if (!sql.isEmpty())

			System.out.println("Sales not found! Please try again. Thank you!");

		else

			System.out.println("Successfully deleted sales record");
	

	}

	
	public static void updateSales() throws SQLException{
		System.out.println("Updating Sales Record");

		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Sales Transaction No: ");
		String sTransactionNo  = scanner.nextLine();

		System.out.print("Enter Item Code : ");
		String iCode = scanner.nextLine();

		System.out.print("Enter Customer ID : ");
		String cID = scanner.nextLine();

		System.out.print("Enter Vendor ID: ");
		int vID = scanner.nextInt();

		System.out.print("Enter Unit Price in USD: ");
		Double uPrice = scanner.nextDouble();

		System.out.print("Enter Quantity : ");
		int qty = scanner.nextInt();

		System.out.print("Enter Customer ID : ");
		String sDate = scanner.nextLine();

		Connection conn = Connect.getConnection();
		PreparedStatement myStmt;

		try {

			

			String sql = "UPDATE Sales SET ";

			if (null != sTransactionNo) {
				sql += " salesTransactionNo = ?,";
			}

			if (null != iCode) {
				sql += " itemCode = ?";
			}

			sql += " WHERE salesTransactionNo =?";

			myStmt = conn.prepareStatement(sql);
			myStmt.setString(1, sTransactionNo);
			myStmt.setString(2, iCode);
			myStmt.setString(3, cID);
			myStmt.setInt(4, vID);
			myStmt.setDouble(5, uPrice);
			myStmt.setInt(6, qty);
			myStmt.setString(7, sDate);

			// execute the java preparedstatement

			myStmt.executeUpdate();

			conn.close();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.err.println("Got an exception! Please try again. Thank you!");
		}
		System.out.println("Successfully updated sales details");
	
	}

	
	public static void searchSales() throws SQLException{
      System.out.println("Searching Sales Record");
		ArrayList<String> rowArray = new ArrayList<String>();

		Scanner scanner = new Scanner(System.in);
		String sql = "SELECT * FROM Sales WHERE salesTransactionNo = ?";
		System.out.print("Enter the sales Transaction No :  ");
		int dNumber = scanner.nextInt();
      int count=0;
		Connection conn = Connect.getConnection();
		// PreparedStatement myStmt;
		try {

			PreparedStatement myStmt = conn.prepareStatement(sql);
			myStmt.setInt(1, dNumber);
			ResultSet rs = myStmt.executeQuery();
         System.out.println();

			while (rs.next()) {
				rowArray.add(rs.getString(1));
				rowArray.add(rs.getString(2));
				rowArray.add(rs.getString(3));
				rowArray.add(rs.getString(4));
				rowArray.add(rs.getString(5));
				rowArray.add(rs.getString(6));
				rowArray.add(rs.getString(7));

				System.out.println(rowArray);
			   count++;
         }
			// myStmt.executeUpdate();
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			System.err.println("Got an exception! Please try again. Thank you!");
		}
		if (count==0)

			System.out.println("Sales not found! Please try again. Thank you!");

		else

			System.out.println("Successfully found the sales record");


	}

}
