//test file

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.math.BigDecimal;
import java.sql.ResultSet;

public class DBOps {

	public static void main(String[] args){

		try {
			Connection conn = Connect.getConnection();
			// change this to whatever method you want to test.
			// Make sure the Connect.java points to your database
			selectExample(conn);
			conn.close();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void insertExample(Connection conn) throws SQLException {
		String sql = "INSERT INTO vendor (vendorID, vendorName, streetAddress, city, state, zipcode, telephoneNo, remittanceInfo, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setInt(1,600);
		statement.setString(2, "TestVendor");
		statement.setString(3, "Test 12345");
		statement.setString(4, "Chicago");
		statement.setString(5, "Illinois");
		statement.setInt(6,60124);
		statement.setString(7,"8888888888");
		statement.setString(8,"00000zzzzz0000");
		statement.setString(9,"Test@Test.com");


		int rowsAffected = statement.executeUpdate();
		if (rowsAffected > 0) {
			System.out.println("A new vendor information was inserted successfully!");
		}
	}

	public static void updateExample(Connection conn) throws SQLException {
		String sql = "UPDATE vendor SET vendorName=?, email=? WHERE vendorID=?";
		PreparedStatement statement = conn.prepareStatement(sql);

		statement.setString(1, "Test");
		statement.setString(2, "noemailaddress");
		statement.setInt(3,600);

		int rowsAffected = statement.executeUpdate();
		if (rowsAffected > 0) {
			System.out.println("Successfully updated "+rowsAffected+"row(s)");
		}

	}

	public static void deleteExample(Connection conn) throws SQLException {
		String sql = "DELETE FROM vendor WHERE vendorID=?";

		PreparedStatement statement = conn.prepareStatement(sql);

		statement.setInt(1, 600);
		int rowsAffected = statement.executeUpdate();
		if (rowsAffected > 0) {
			System.out.println("Successfully deleted "+rowsAffected+"row(s)");
		}

	}

	public static void selectExample(Connection conn) throws SQLException {
		String sql = "SELECT * FROM vendor";

		Statement statement = conn.createStatement();
		ResultSet result = statement.executeQuery(sql);

		while (result.next()){
			int vendorID = result.getInt(1);
			String vendorName = result.getString(2);
			String streetAddress = result.getString(3);
			String city = result.getString(4);
			String state= result.getString(5);
			int zipcode= result.getInt("zipcode");
			String telephoneNo= result.getString(5);
			String remittanceInfo= result.getString(6);
			String email= result.getString(7);

			System.out.println(vendorID+" - "+vendorName+" - "+streetAddress+" - "+city+" - "+state+" - "+zipcode+" - "+telephoneNo+" - "+remittanceInfo+" - "+email);
		}
	}

}
